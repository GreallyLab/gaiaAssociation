# gaiaAssociation
Compare ATAC-seq datasets against loci datasets to see if there is a specific enrichment between a particular loci set in a cell type
